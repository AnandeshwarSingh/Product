package com.application.service;
import org.springframework.data.domain.Page;

import com.application.dto.CategoryDTO;
import com.application.model.Category;

public interface CategoryService {
	public boolean addCategory(CategoryDTO catDTO);

	public Category getById(int cid);

	public boolean updateCategory(CategoryDTO catDTO, int cid);

	public boolean deleteCategory(int cid);

	public Page<Category> getCategory(int pageSize);

}
