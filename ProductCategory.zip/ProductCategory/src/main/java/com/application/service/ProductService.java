package com.application.service;
import java.util.List;

import org.springframework.data.domain.Page;

import com.application.dto.ProductDTO;
import com.application.model.Product;

public interface ProductService {
	public boolean addProduct(ProductDTO proDTO);

	public Product getById(int pid);

	public boolean updateProduct(ProductDTO proDTO, int pid);

	public boolean deleteProduct(int pid);

	public Page<Product> getProduct(int pageSize);

	public List<Product> viewProduct();

}
