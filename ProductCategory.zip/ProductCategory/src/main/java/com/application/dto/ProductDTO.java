package com.application.dto;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@NoArgsConstructor
@Data
public class ProductDTO {
	private String pname;
	public void setPname(String pname) {
		this.pname = pname;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	private int cid;
	public String getPname() {
		return pname;
	}
	public int getCid() {
		
		return cid;
	}
}
