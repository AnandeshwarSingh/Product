package com.application.dto;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class CategoryDTO {
	private String cname;

	public String getCname() {
		return cname;
	}
	
	public void setCname(String cname)
	{
		this.cname = cname;
	}
	
	
	
}
